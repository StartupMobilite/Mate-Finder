using AppStudio.Uwp.Controls;
using Windows.UI.Xaml.Controls;

namespace DailyStone.Layouts.Detail
{
    public sealed partial class MultiColumnDetailLayout : BaseDetailLayout
    {
        public MultiColumnDetailLayout()
        {
            InitializeComponent();
        }        
    }
}
