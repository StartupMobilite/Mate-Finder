namespace DailyStone.Layouts.List
{
    public sealed partial class MenuMedium : ListLayoutBase
    {
        public MenuMedium() : base()
        {
            this.InitializeComponent();
        }
    }
}
