//---------------------------------------------------------------------------
//
// <copyright file="MiseAJoursListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>1/15/2016 2:13:09 PM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml;
using AppStudio.DataProviders.Rss;
using DailyStone.Sections;
using DailyStone.ViewModels;
using AppStudio.Uwp;

namespace DailyStone.Pages
{
    public sealed partial class MiseAJoursListPage : Page
    {
        public MiseAJoursListPage()
        {
            this.ViewModel = ListViewModel.CreateNew(Singleton<MiseAJoursConfig>.Instance);

            this.InitializeComponent();
        }

        public ListViewModel ViewModel { get; set; }


        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            await this.ViewModel.LoadDataAsync();
            base.OnNavigatedTo(e);
        }

    }
}
