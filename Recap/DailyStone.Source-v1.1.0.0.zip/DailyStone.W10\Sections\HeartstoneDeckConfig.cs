


using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;
using AppStudio.DataProviders.Bing;
using AppStudio.Uwp.Actions;
using AppStudio.Uwp.Commands;
using AppStudio.Uwp.Navigation;
using AppStudio.Uwp;
using System.Linq;
using DailyStone.Config;
using DailyStone.ViewModels;

namespace DailyStone.Sections
{
	public class HeartstoneDeckConfig : SectionConfigBase<BingSchema>
    {
	    public override Func<Task<IEnumerable<BingSchema>>> LoadDataAsyncFunc
        {
            get
            {
                var config = new BingDataConfig
                {
                    Country = BingCountry.France,
                    Query = @"Heartstone deck"
                };

                return () => Singleton<BingDataProvider>.Instance.LoadDataAsync(config, MaxRecords);
            }
        }

        public override ListPageConfig<BingSchema> ListPage
        {
            get 
            {
                return new ListPageConfig<BingSchema>
                {
                    Title = "Heartstone deck",

					PageTitle = "Heartstone deck",

                    ListNavigationInfo = NavigationInfo.FromPage("HeartstoneDeckListPage"),

                    LayoutBindings = (viewModel, item) =>
                    {
                        viewModel.Title = item.Title.ToSafeString();
                        viewModel.SubTitle = item.Summary.ToSafeString();
                        viewModel.Description = null;
                        viewModel.ImageUrl = ItemViewModel.LoadSafeUrl(null);
                    },
                    DetailNavigation = (item) =>
                    {
                        return new NavigationInfo
                        {
                            NavigationType = NavigationType.DeepLink,
                            TargetUri = new Uri(item.Link)
                        };
                    }
                };
            }
        }

        public override DetailPageConfig<BingSchema> DetailPage
        {
            get { return null; }
        }
    }
}
