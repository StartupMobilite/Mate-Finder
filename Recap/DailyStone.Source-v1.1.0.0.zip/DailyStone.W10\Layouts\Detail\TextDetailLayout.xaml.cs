using System;
using AppStudio.Uwp.Controls;
using Windows.UI.Xaml.Controls;

namespace DailyStone.Layouts.Detail
{
    public sealed partial class TextDetailLayout : BaseDetailLayout
    {
        public TextDetailLayout()
        {
            InitializeComponent();
        }
    }
}
